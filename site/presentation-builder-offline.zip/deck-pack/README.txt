OFFLINE MONTHLY PRESENTATION BUILDER
====================================
100% Client-Side Private PowerPoint Generator

HOW TO RUN:
1. Double-click `index.html` in Chrome, Edge, Safari, or Firefox.
2. No internet connection or web server required.
3. 100% private: all calculations and PowerPoint generation happen inside your browser.
