OFFLINE MONTHLY PRESENTATION BUILDER
====================================
100% Client-Side Private PowerPoint Generator

HOW TO RUN:
1. Double-click index.html in Google Chrome, Microsoft Edge, Mozilla Firefox, or Safari.
2. No internet connection or local web server required.
3. 100% private: all calculations and PowerPoint updates happen strictly inside your browser.
4. Upload your monthly .pptx template and 4 weekly data reports to generate an identical presentation with updated numbers.
