OFFLINE MONTHLY PRESENTATION BUILDER
====================================
100% Client-Side Private PowerPoint Generator

HOW TO RUN:
1. Double-click `index.html` in Chrome, Edge, Safari, or Firefox.
2. No web server, internet connection, or company network access required.
3. Zero data is transmitted to external servers. All data processing and PowerPoint generation occurs in your local browser sandbox.
